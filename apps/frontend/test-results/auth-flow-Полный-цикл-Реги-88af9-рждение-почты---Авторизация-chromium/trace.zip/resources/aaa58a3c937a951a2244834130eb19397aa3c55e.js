(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__37942dcf._.css",
  "static/chunks/_50bd3bb4._.js",
  "static/chunks/apps_frontend_src_41bbc637._.js"
],
    source: "dynamic"
});
