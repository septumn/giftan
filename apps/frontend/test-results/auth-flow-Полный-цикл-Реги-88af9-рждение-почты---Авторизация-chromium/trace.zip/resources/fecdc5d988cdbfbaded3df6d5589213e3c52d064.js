(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_c692a0b8._.js",
  "static/chunks/apps_frontend_src_2be50010._.js",
  "static/chunks/apps_frontend_src_app_auth_page_module_64ed5279.css"
],
    source: "dynamic"
});
